function displayName(varOne){
    console.log("Hello, " + varOne);
}

displayName("Vincent");

function displayTemp(inputNum){
    let c = ((inputNum + 40) / 1.8) - 40;
    let f = ((c+10) * 1.8) - 40;

    console.log(f + 'F is ' + c);
    console.log(c + 'c is ' + f);
}

displayTemp(100);