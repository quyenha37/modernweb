let x,y,z;
x=10;
y='10';
z=30;

console.log(`x is ${typeof x}`);
console.log(`y is ${typeof y}`);
console.log(`z is ${typeof z}`);

var newX = x++;
console.log(`newX is ${typeof newX}`);

console.log(x==y);

let pastDate = new Date('01/01/1970');
let now = new Date();

console.log(`How many years since epoch ${ now.getFullYear() - pastDate.getFullYear()} year(s)`);
console.log(`How many months since epoch ${ now.getMonth() - pastDate.getMonth()} month(s)`);
console.log(`How many days since epoch ${ now.getDay() - pastDate.getDay()} day(s)`);


