const hobbiesArray = [
    { name: 'Reading', lengthInYearsAtHobby: 3},
    { name: 'Cooking', lengthInYearsAtHobby: 6},
    { name: 'Hiking', lengthInYearsAtHobby: 8}
];

function printHobby(hobby){
    console.log(`${hobby[0].name} enjoyed for ${hobby[0].lengthInYearsAtHobby}`);
}

printHobby(hobbiesArray);

function printHobbies(hobbies){

    for(let i = 0; i < hobbies.length; i++){
        console.log(`${hobbies[i].name}`);
    }
}

printHobbies(hobbiesArray);