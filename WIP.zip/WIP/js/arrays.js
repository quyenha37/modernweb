// function printHobbies(){
//     const hobbies = ["Traveling", "Cooking", "Eating"];

//     const hobbyList = hobbies.map(function (h){
//         return "I like " + h ;
//     });
    
//     console.log("I like 3 things: ");
//     console.log(hobbyList);
// }

function printHobbies(passedArray){
    console.log(`I like ${passedArray.length} thing`);

    for(let i = 0; i < passedArray.length; i++){
        let element = passedArray[i];
        console.log('I like ' + element);
    }
}

var hobbies = ["Traveling", "Cooking", "Eating"];

printHobbies(hobbies);