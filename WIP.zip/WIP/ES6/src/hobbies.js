const hobbiesArray = [
    { name: 'Reading', lengthInYearsAtHobby: 3},
    { name: 'Cooking', lengthInYearsAtHobby: 6},
    { name: 'Hiking', lengthInYearsAtHobby: 8}
];

function returnHobbiesHTML(){
    let hobbyInfo = `
        <ul>
    `;
    hobbiesArray.forEach(hobby => {
        hobbyInfo+= `<li>${hobby.name} ${hobby.lengthInYearsAtHobby}</li>`;
        });
        hobbyInfo+=`</ul>`;
    return hobbyInfo;
}

